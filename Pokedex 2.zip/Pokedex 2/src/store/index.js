import { createStore } from 'vuex';

export default createStore({
    state: {
        deckPokemons: [],
    },
    mutations: {
        addToDeck(state, pokemon) {
            // Ajouter le pokemon du deck
            state.deckPokemons.push(pokemon);
        },
        removeFromDeck(state, pokemon) {
            // Enlever le pokdemon du deckl
            const index = state.deckPokemons.findIndex(p => p === pokemon);
            if (index !== -1) {
                state.deckPokemons.splice(index, 1);
            }
        },
    },
    actions: {
        
    },
    getters: {
        totalDeckPokemons: state => {
            // Calcul de nombre total de pokémons dans le deck
            return state.deckPokemons.length;
        },
        deckPokemonNames: state => {
        
            return state.deckPokemons.map(pokemon => pokemon.name);
        },
    },
});
