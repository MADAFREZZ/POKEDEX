<template>
 
 <div class="logo">
    <img src="/Users/madafrezz/Desktop/pokedex-master/public/logo.png" alt="">
  </div>
  <div>
    <div class="filters">
      <label>
        Rechercher:
        <input v-model="nameFilter" @input="applyFilters" />
      </label>

      <label>
        Type:
        <select v-model="typeFilter" @change="applyFilters">
          <option value="">Tous</option>
          <option v-for="type in uniqueTypes" :key="type" :value="type">{{ type }}</option>
        </select>
      </label>
    </div>

  <!-- Boutton pour aller au deck bas -->
    <router-link to="/my-deck">
      <button class="deck">Mon Deck</button>
    </router-link>

    <div class="card-container">
      <div v-for="pokemon in filteredPokemons" :key="pokemon.pokedex_number" class="card">
        <pokemon-card :pokemon="pokemon" @add-to-deck="addToDeck" @remove-from-deck="removeFromDeck" @show-details="showDetailsModal"></pokemon-card>
      </div>
    </div>

<!-- Pagination Bas de page  -->

    <div>
      <button @click="prevPage" :disabled="currentPage === 1">Précédent</button>
      <span>Page {{ currentPage }} sur {{ totalPages }}</span>
      <button @click="nextPage" :disabled="currentPage === totalPages">Suivant</button>
    </div>


    <!-- Détails des pokemons -->
    <pokemon-details-modal v-if="isModalVisible" :selected-pokemon="selectedPokemon" :deck-pokemons="selectedPokemons" @close="closeDetailsModal" @add-to-deck="addToDeck" @remove-from-deck="removeFromDeck"></pokemon-details-modal>

  </div>
</template>

<script>
import PokemonCard from './PokemonCard.vue';
import data from '../../assets/data/pokemon.json';
import PokemonDetailsModal from "./PokemonDetailsModal.vue";


export default {
  components: {
    PokemonDetailsModal,
    PokemonCard
  },
  data() {
    return {
      pokemons: data, 
      itemsPerPage: 30,
      currentPage: 1,
      nameFilter: '',
      classificationFilter: '',
      typeFilter: '',
      isModalVisible: false,
      selectedPokemon: null,
      selectedPokemons: []  
    };
  },
  computed: {
    totalPages() {
      return Math.ceil(this.pokemons.length / this.itemsPerPage);
    },
    paginatedPokemons() {
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;
      return this.pokemons.slice(start, end);
    },
    uniqueTypes() {
      const types = new Set();
      this.pokemons.forEach(pokemon => {
        if (pokemon.type1) types.add(pokemon.type1);
        if (pokemon.type2) types.add(pokemon.type2);
      });
      return Array.from(types);
    },
    filteredPokemons() {
      let filteredList = this.pokemons;

      if (this.nameFilter) {
        const lowerCaseNameFilter = this.nameFilter.toLowerCase();
        filteredList = filteredList.filter(pokemon => pokemon.name.toLowerCase().includes(lowerCaseNameFilter));
      }

      if (this.classificationFilter) {
        const lowerCaseClassFilter = this.classificationFilter.toLowerCase();
        filteredList = filteredList.filter(pokemon => pokemon.classfication.toLowerCase().includes(lowerCaseClassFilter));
      }

      if (this.typeFilter) {
        filteredList = filteredList.filter(pokemon => pokemon.type1 === this.typeFilter || pokemon.type2 === this.typeFilter);
      }

      return filteredList.slice((this.currentPage - 1) * this.itemsPerPage, this.currentPage * this.itemsPerPage);
    }
  },
  methods: {
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++;
      }
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
      }
    },
    applyFilters() {
      
    },
    showDetailsModal(pokemon) {
      console.log('showDetailsModal called');
      this.selectedPokemon = pokemon;
      this.isModalVisible = true;
    },
    closeDetailsModal() {
      console.log('closeDetailsModal called');
      this.isModalVisible = false;
    },
    addToDeck(pokemon) {
      // Ajoute le pokémon au deck
      this.selectedPokemons.push(pokemon);
    },
    removeFromDeck(pokemon) {
      // Supprime le pokémon du deck
      const index = this.selectedPokemons.indexOf(pokemon);
      if (index !== -1) {
        this.selectedPokemons.splice(index, 1);
      }
    },
    viewDeck() {
      this.$router.push({ name: 'my-deck' });
    }
  }
};
</script>

<style scoped>
.filters {
  margin-bottom: 20px;
}

.card-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.card {
  flex: 0 0 calc(33.33% - 10px); 
  margin-bottom: 20px; 
  box-sizing: border-box;
  border-color: red;
  border-width: 3px;
  border-radius: 20px;

}

.div>card {
  background-color: red;
}

button{
  color: white;
  background-color: red;
  margin-left: 5%;
  margin-right: 5%;
  border-radius: 10px;
  padding: 10px;

}

img{
  width: 60%;
  justify-content: center;
  margin-bottom: 10%;
}


.deck{
  margin-bottom: 10px;
}

@media (max-width: 992px) {
  .card {
    flex: 0 0 calc(50% - 10px);
  }
}

@media (max-width: 768px) {
  .card {
    flex: 0 0 calc(100% - 10px);
  }
}
</style>
