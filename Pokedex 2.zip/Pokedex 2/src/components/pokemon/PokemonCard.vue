<template>
  <div class="card" @click="openDetailsModal">
    <p># {{ pokemon.pokedex_number }}</p>
    <h2>{{ pokemon.name }}</h2>
    <img :src="getImagePath(pokemon.name)" :alt="pokemon.name + ' Image'" />
    <div class="flex-container">
    <p>{{ pokemon.type1 }}{{ pokemon.type2 ? ' / ' + pokemon.type2 : '' }}</p>
    </div>
    
  </div>
</template>

<script>
export default {
  props: {
    pokemon: Object
  },
  methods: {
    getImagePath(pokemonName) {
      return 'images/' + pokemonName.toLowerCase() + '.png';
    },
    openDetailsModal() {
      console.log("openDetailsModal");
      this.$emit('show-details', this.pokemon);
    }
  }
};
</script>

<style scoped>
.card {
  border: 1px solid #ccc;
  padding: 10px;
  margin: 10px;
  width: 250px;
  height: 260px;
  display: inline-block;
  cursor: pointer;
}

img {
  max-width: 100%;
  height: auto;
}

p{
  padding: 10px;
}

.flex-container{
  display: flex;
  justify-content: center;
}

</style>
