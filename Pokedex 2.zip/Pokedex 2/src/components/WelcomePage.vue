
<template>
<body>
   <div>
     <h1>Salut Sacha 🧢</h1>
     <p>Heureux de te retrouver !</p>
     <router-link to="/pokemon-list">Voir le Pokédex</router-link>
   </div>
</body> 
</template>

<script>
export default {};
</script>


<style>
body {
  margin: 0;
  padding: 0;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}
</style>
