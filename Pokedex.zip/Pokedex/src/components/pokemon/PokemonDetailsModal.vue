<template>
  <div class="modal">
    <div class="modal-content">
      <span class="close" @click="closeModal">&times;</span>
      <h2>{{ selectedPokemon.name }}</h2>
      <img :src="getImagePath(selectedPokemon.name)" :alt="selectedPokemon.name + ' Image'" />
      <table>
  <tr>
    <td><strong>Type</strong></td>
    <td>{{ selectedPokemon.type1 }}{{ selectedPokemon.type2 ? ' / ' + selectedPokemon.type2 : '' }}</td>
  </tr>
  <tr>
    <td><strong>PV</strong></td>
    <td>{{ selectedPokemon.hp }}</td>
  </tr>
  <tr>
    <td><strong>Attaque</strong></td>
    <td>{{ selectedPokemon.attack }}</td>
  </tr>
  <tr>
    <td><strong>SP Attaque</strong></td>
    <td>{{ selectedPokemon.sp_attack }}</td>
  </tr>
  <tr>
    <td><strong>Défense</strong></td>
    <td>{{ selectedPokemon.defense }}</td>
  </tr>
  <tr>
    <td><strong>SP Défense</strong></td>
    <td>{{ selectedPokemon.sp_defense }}</td>
  </tr>
  <tr>
    <td><strong>Vitesse</strong></td>
    <td>{{ selectedPokemon.speed }}</td>
  </tr>
</table>
    </div>

    <!-- Boutons ajouter et enlever du deck -->
    <div class="deck-actions">
      <button @click="addToDeck" :disabled="isInDeck || isDeckFull">Ajouter au Deck</button>
      <button @click="removeFromDeck" :disabled="!isInDeck">Retirer du Deck</button>
    </div>
  </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex';

export default {
  props: {
    selectedPokemon: Object,
  },
  computed: {
    ...mapState(['deckPokemons']),
    isInDeck() {
      // Verifie si le pokemon est dejà présent dans le deck
      return this.deckPokemons.some(pokemon => pokemon.pokedex_number === this.selectedPokemon.pokedex_number);
    },
    isDeckFull() {
      // Verifie si le deck est plein 
      return this.deckPokemons.length >= 5;
    },
  },
  methods: {
    getImagePath(pokemonName) {
    
      return 'images/' + pokemonName.toLowerCase() + '.png';
    },
    closeModal() {
      console.log('Closing modal');
      this.$emit('close');
    },
    ...mapMutations(['addToDeck', 'removeFromDeck']),
    addToDeck() {
      if (!this.isInDeck && !this.isDeckFull) {
        // Commit the addToDeck mutation from Vuex store
        console.log('adding to deck')
        this.$store.commit('addToDeck', this.selectedPokemon);
      }
    },
    removeFromDeck() {
      if (this.isInDeck) {
        console.log('removing from deck')
        this.$store.commit('removeFromDeck', this.selectedPokemon);
      }
    },
  }
};
</script>

<style scoped>
/* Style du modal */
.modal {
  display: block;
  position: fixed;
  z-index: 1000;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(67, 15, 15, 0.7);
}

.modal-content {
  background-color: #ffffff;
  margin: 10% auto;
  padding: 20px;
  width: 60%;
  border-radius: 20px;
}

.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
  cursor: pointer;
}

.close:hover {
  color: rgb(255, 0, 0);
  text-decoration: none;
  cursor: pointer;
}


/* Styles additionnels */
.deck-actions {
  margin-top: 20px;
}

.deck-actions button {
  margin-right: 10px;
}

table{
  display: inline-block;
  justify-content: center;
}
img{
  width: 20%;
}

button{
  color: white;
  background-color: red;
  margin-left: 5%;
  margin-right: 5%;
  border-radius: 10px;
  padding: 10px;
  justify-content: center;

}

</style>
