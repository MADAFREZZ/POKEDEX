<!-- MyDeck.vue -->
<template>

  <div>
    <h2>Mon Deck</h2>
    <div v-if="deckPokemons.length === 0">Votre deck est vide.</div>
    <div v-else>
      <div v-for="pokemon in deckPokemons" :key="pokemon.pokedex_number" class="deck-card">
        <pokemon-card :pokemon="pokemon" @show-details="showDetailsModal"></pokemon-card>
      </div>
    </div>

    <!-- détails des pokémonbs pour le deck -->
    <pokemon-details-modal
        v-if="isModalVisible"
        :selected-pokemon="selectedPokemon"
        :deck-pokemons="deckPokemons"
        @close="closeDetailsModal"
    ></pokemon-details-modal>

    <router-link to="/pokemon-list">Revenir au Pokédex</router-link>
  </div>

</template>

<script>

import { mapState } from 'vuex';
import PokemonCard from "@/components/pokemon/PokemonCard.vue";
import PokemonDetailsModal from "@/components/pokemon/PokemonDetailsModal.vue";


export default {
  components: {
    PokemonCard,
    PokemonDetailsModal,
  },
  computed: {
    ...mapState(['deckPokemons']),
  },
  data() {
    return {
      isModalVisible: false,
      selectedPokemon: null,
    };
  },
  methods: {
    showDetailsModal(pokemon) {
      this.selectedPokemon = pokemon;
      this.isModalVisible = true;
    },
    closeDetailsModal() {
      this.isModalVisible = false;
    },
  },
};
</script>

<style scoped>

.deck-card {
  margin-bottom: 20px;
}

</style>
